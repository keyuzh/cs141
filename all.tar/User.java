class UserThread
    extends Thread
{
    User(int id)
    {
    }
}
