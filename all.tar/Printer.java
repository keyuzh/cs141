class Printer
    // extends Thread
{
    Printer(int id)
    {
    }
    void print(StringBuffer b)
    {
    }
}
