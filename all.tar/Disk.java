class Disk
    // extends Thread
{
    void read()
    {
    }
    void write()
    {
    }
}
